package com;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Created by 10049992 on 2016/12/23.
 */


public class MainTest
{


    public static void main(String[] args)
    {

        String noticeInfo = "";

        if(!noticeInfo.isEmpty())
        {
            int bb = 1;
        }

        if(notEmptyStr(noticeInfo))
        {
            int cc = 1;
        }


        int a = 1;


    }

    public static boolean notEmptyStr(String str)
    {
        return str != null && str.trim().length() > 0;
    }

    public static void pushuTop(List<List<String>> lstlst)
    {
        if(lstlst != null)
        {
            Iterator<List<String>> it = lstlst.iterator();
            List<String> abclst = new ArrayList<>();
            for(; it.hasNext(); )
            {
                List<String> lst =  it.next();
                if("ABC".equals(lst.get(0)))
                {
                    abclst.addAll(lst);
                    it.remove();
                    break;
                }
                int b = 1;
            }
            lstlst.add(0,abclst);

            int a = 1;


        }
    }



    /**
     * �󲹼����ٶȽ��ͣ�����һ��ָ���Բ�������һ��أ���S��һ�����ϣ�A��S��һ���Ӽ�����S�����в�����A��Ԫ����ɵļ��ϣ�
     * �����Ӽ�A��S�еľ��Բ�������Ʋ������༯����
     *
     * @param totalColl ȫ��
     * @param subColl   �Ӽ�
     * @return ����
     */
    public static Set<Object> getComplementary(final Collection totalColl, final Collection subColl)
    {
        Set<Object> result = new HashSet<Object>();
        if (totalColl != null && subColl != null)
        {
            result.addAll(totalColl);
            result.removeAll(subColl);
        }
        return result;

    }

    public static Set<Object> getIntersection(final Collection oneColl, final Collection otherColl)
    {
        Set<Object> result = new HashSet<Object>();
        if (oneColl != null && otherColl != null)
        {
            result.addAll(oneColl);
            result.retainAll(otherColl);
        }
        return result;
    }


    /**
     * ����˿�
     *
     * @param portInfo �˿���Ϣ����Ԫ�����ܡ��Ͷ˿�֮����/�ָ�,�˿ڸ�ʽ�� 6200-1/3--R8EGF/(Eth_U)1/3
     * @return �˿��ַ���, ��ʽ�磺BN:ME{92930809},EQ={/r=0/sh=1/sl=7},PTP={/p=1_7},SIP={123}
     */
    public static String createEndValueByTxt(final String portInfo)
    {
        String portValue = "";
        if (!isStrNull(portInfo))
        {
            String me = null;
            String sh = null;
            String port = null;
            String subPort = null;
            String temp = portInfo.replaceAll(" ", "");
            String[] strArr = temp.split("/");
            if (strArr != null)
            {
                me = !isStrNull(strArr[0]) ? strArr[0] : null;
                sh = !isStrNull(strArr[1]) ? strArr[1] : null;
                port = !isStrNull(strArr[2]) ? strArr[2] : null;
                subPort = (strArr.length >= 4 && !isStrNull(strArr[3])) ? strArr[3] : null;
            }
            //BN:ME{92930809},EQ={/r=0/sh=1/sl=7},PTP={/p=1_7},SIP={123}
            String meVal = queryME(me);
            String shVal = createSh(sh);
            String portVal = createPort(port);
            String subPortVal = createSIP(subPort);
            if (!isStrNull(subPortVal))
            {
                portValue = String.format("%s,%s,%s,%s", meVal, shVal, portVal, subPortVal);
            }
            else
            {
                portValue = String.format("%s,%s,%s", meVal, shVal, portVal);
            }
        }
        return portValue;
    }


    // ������Ԫ��ǩ��ѯ����Ԫvalue
    private static String queryME(String meLabel)
    {
        return meLabel;
    }

    // ��������Ļ���label���������Ӽ�,����Ļ��ܱ�ǩ�� 3--R8EGF��3--4--R8EGF ,����3Ϊ��λ��sl��4Ϊ�Ӳ�λ��ssl
    // ��Ҫ�����ʽΪ EQ={/r=0/sh=1/sl=7} �� EQ={/r=0/sh=0/sl=1/ssl=2}
    private static String createSh(final String shLabel)
    {
        String sh = "";
        if (!isStrNull(shLabel))
        {
            String sl = null;
            String ssl = null;

            String temp = shLabel.replaceAll(" ", "");
            String[] strArr = temp.split("--");
            if (strArr != null)
            {
                sl = isNumeric(strArr[0]) ? strArr[0] : null;
                ssl = isNumeric(strArr[1]) ? strArr[1] : null;
            }
            if (!isStrNull(sl) && !isStrNull(ssl))
            {
                sh = String.format("EQ={/r=0/sh=1/sl=%s/ssl=%s}", sl, ssl);
            }
            else if (!isStrNull(sl))
            {
                sh = String.format("EQ={/r=0/sh=1/sl=%s}", sl);
            }
        }
        return sh;
    }

    // ����˿�ֵ����������磺(Eth_U)1������Eth_UΪ�˿����ͣ�1Ϊ�˿ںţ����Ϊ��PTP={/p=1_7} �� FTP={/p=14_2}
    private static String createPort(final String portLabel)
    {
        String port = "";
        if (!isStrNull(portLabel))
        {
            String temp = portLabel.replaceAll(" ", "");
            String typeLabel = temp.substring(temp.indexOf("(") + 1, temp.indexOf(")"));
            String type = "";
            String typeNum = "";
            if ("Eth_U".equals(typeLabel))
            {
                type = "PTP";
                typeNum = "1";
            }
            else
            {
                type = "FTP";
                typeNum = "14";
            }
            String portNum = temp.substring(temp.indexOf(")") + 1, temp.length());
            if (!isStrNull(type) && isNumeric(portNum))
            {
                port = String.format("%s={/p=%s_%s}", type, typeNum, portNum);
            }
        }
        return port;
    }

    private static String createSIP(final String sipLabel)
    {
        String sip = "";
        String temp = sipLabel;
        if (!isStrNull(temp) && isNumeric(temp.trim()))
        {
            sip = String.format("SIP={%s}", sipLabel.trim());
        }
        return sip;
    }

    public static boolean isNumeric(String str)
    {
        if (str != null)
        {
            Pattern pattern = Pattern.compile("[0-9]*");
            return pattern.matcher(str).matches();
        }
        else
        {
            return false;
        }
    }

    public static boolean isStrNull(String str)
    {
        return str == null || str.trim().equals("");
    }


}
