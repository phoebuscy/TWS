package com.phoebuscy;

/**
 * Created by 10049992 on 2017/3/9.
 */
public class SpyMain
{

    public int getInt(int a)
    {
        if (a > 1)
        {
            return 100;
        }
        else
        {
            return 5;
        }
    }


}
