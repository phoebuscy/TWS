/**
 * Created by caiyong on 2017/3/5.
 */
public class TMainTest
{

    public int getInt(int a)
    {
        if (a > 1)
        {
            return 100;
        }
        else
        {
            return 0;
        }
    }
}
